import parent #prints the same info as parent.py, creates a .pyc file in directory

print(locals()) #gives access/visibility to what variables are in your current namespace
